package com.mtc.math;

public class Arithmetic {
	
	public int sum(int a, int b) {
		return a+b;
	}

}

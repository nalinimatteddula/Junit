package com.mtc.math;

import static org.junit.jupiter.api.Assertions.assertEquals;
import java.util.stream.Stream;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.MethodSource;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;

@RunWith(Parameterized.class)
class ParameterizedArithmeticTest {

	int param1;
	int param2;
	int expectedResult;
	
	public static Stream<int[]> dataSet(){
		return Stream.of(new int[] {10,20,30},new int[] {20,20,40},new int[] {30,20,50}, new int[] {50,20,70});
	}
	
	@ParameterizedTest
	@MethodSource("dataSet")
	void testSum(int[] values) {
		Arithmetic arithmetic = new Arithmetic();
		param1 = values[0];
		param2 = values[1];
		expectedResult = values[2];
		int actualResult = arithmetic.sum(param1, param2);
		assertEquals(expectedResult,actualResult);
	}

}
